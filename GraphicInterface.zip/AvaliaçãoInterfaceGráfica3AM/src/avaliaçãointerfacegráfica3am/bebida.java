package avaliaçãointerfacegráfica3am;

public class bebida extends produto{
    private int tipoBebida;
    private int medidaBebida;

    public bebida(int tipoBebida, int medidaBebida, String nome, int quantidade, Double preco, int embalagem) {
        super(nome, quantidade, preco, embalagem);
        this.tipoBebida = tipoBebida;
        this.medidaBebida = medidaBebida;
    }
    
    public String getTipoBebidaLiteral(){
        String retorno = "";
        if (this.tipoBebida == 1){
            retorno = "Água";
        } else if (this.tipoBebida == 2){
            retorno = "Suco";
        } else if (this.tipoBebida == 3){
            retorno = "Refrigerante";
        } else if (this.tipoBebida == 4){
            retorno = "Outro";
        }
        return retorno;
    }
    
    public String getEmbalagemLiteral(){
        String retorno = "";
        if (this.medidaBebida == 1){
            retorno = super.embalagem + "ml";
        } else {
            retorno = super.embalagem + "l";
        }
        return retorno;
    }

    public int getTipoBebida() {
        return tipoBebida;
    }

    public void setTipoBebida(int tipoBebida) {
        this.tipoBebida = tipoBebida;
    }
    
     public int getMedidaBebida() {
        return medidaBebida;
    }

    public void setMedidaBebida(int medidaBebida) {
        this.medidaBebida = medidaBebida;
    }
}
