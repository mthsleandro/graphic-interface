package avaliaçãointerfacegráfica3am;

public class alimento extends produto{
    private int tipoAlimento;
    private int medidaAlimento;

    public alimento(int tipoAlimento, int medidaAlimento, String nome, int quantidade, Double preco, int embalagem) {
        super(nome, quantidade, preco, embalagem);
        this.tipoAlimento = tipoAlimento;
        this.medidaAlimento = medidaAlimento;
    }
    
    public String getTipoAlimentoLiteral(){
        String retorno = "";
        if (this.tipoAlimento == 1){
            retorno = "Prato";
        } else if (this.tipoAlimento == 2){
            retorno = "Lanche";
        } else if (this.tipoAlimento == 3){
            retorno = "Diversos";
        }
        return retorno;
    }
    
    public String getEmbalagemLiteral(){
        String retorno = "";
        if (this.medidaAlimento == 1){
            retorno = super.embalagem + "g";
        } else {
            retorno = super.embalagem + "kg";
        }
        return retorno;
    }
    
    public int getTipoAlimento() {
        return tipoAlimento;
    }

    public void setTipoAlimento(int tipoAlimento) {
        this.tipoAlimento = tipoAlimento;
    }   

    public int getMedidaAlimento() {
        return medidaAlimento;
    }

    public void setMedidaAlimento(int medidaAlimento) {
        this.medidaAlimento = medidaAlimento;
    }
}
