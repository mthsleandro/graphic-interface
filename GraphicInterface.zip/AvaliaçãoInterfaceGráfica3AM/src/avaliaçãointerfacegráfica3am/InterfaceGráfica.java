package avaliaçãointerfacegráfica3am;

public class InterfaceGráfica {

    public static void main(String[] args) {
        
    }
    
}
