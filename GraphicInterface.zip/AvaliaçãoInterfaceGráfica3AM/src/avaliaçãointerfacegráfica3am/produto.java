package avaliaçãointerfacegráfica3am;

public class produto {
    private String nome;
    private int quantidade;
    private Double preco;
    public int embalagem;

    public produto(String nome, int quantidade, Double preco, int embalagem) {
        this.nome = nome;
        this.quantidade = quantidade;
        this.preco = preco;
        this.embalagem = embalagem;
    }

public boolean retirada(int quantidadeRetirada) {
        boolean resultado;
        if (quantidadeRetirada >= 0) {
            this.quantidade = this.quantidade - quantidadeRetirada;
            resultado = true;
        } else {
            resultado = false;
        }
        return resultado;
    }

     public boolean entrada(int quantidadeEntrada) {
        boolean resultado;
        if (quantidadeEntrada > 0) {
            this.quantidade = this.quantidade + quantidadeEntrada;
            resultado = true;
        } else {
            resultado = false;
        }
        return resultado;
    }
     
    public String getNome() {
        return nome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public Double getPreco() {
        return preco;
    }
    
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public int getEmbalagem() {
        return embalagem;
    }

    public void setEmbalagem(int embalagem) {
        this.embalagem = embalagem;
    }
}


