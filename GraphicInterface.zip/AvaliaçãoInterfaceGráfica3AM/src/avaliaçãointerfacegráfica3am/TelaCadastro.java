package avaliaçãointerfacegráfica3am;

import java.util.LinkedList;
import javax.swing.JOptionPane;

public class TelaCadastro extends javax.swing.JFrame {

    LinkedList<produto> listaProdutos;

    public TelaCadastro(LinkedList<produto> listaProdutos) {
        initComponents();
        this.listaProdutos = listaProdutos;
        JCBtipoAlimento.setEnabled(false);
        JCBtipoBebida.setEnabled(false);
        JTFembalagemAlimento.setEnabled(false);
        JTFembalagemBebida.setEnabled(false);
        JCBmedidaAlimento.setEnabled(false);
        JCBmedidaBebida.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        canvas1 = new java.awt.Canvas();
        JLnome = new javax.swing.JLabel();
        JTFnome = new javax.swing.JTextField();
        JLquantidade = new javax.swing.JLabel();
        JLpreco = new javax.swing.JLabel();
        JBsalvar = new javax.swing.JButton();
        JBcancelar = new javax.swing.JButton();
        JTFpreco = new javax.swing.JTextField();
        JLtipoProduto = new javax.swing.JLabel();
        JCBtipoProduto = new javax.swing.JComboBox<>();
        jSeparator1 = new javax.swing.JSeparator();
        JLproduto = new javax.swing.JLabel();
        JLtipoAlimento = new javax.swing.JLabel();
        JCBtipoAlimento = new javax.swing.JComboBox<>();
        JLalimento = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        JLbebida = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        JLembalagemBebida = new javax.swing.JLabel();
        JTFembalagemAlimento = new javax.swing.JTextField();
        JLtipoBebida = new javax.swing.JLabel();
        JCBtipoBebida = new javax.swing.JComboBox<>();
        JSquantidade = new javax.swing.JSpinner();
        JLmedidaBebida = new javax.swing.JLabel();
        JCBmedidaBebida = new javax.swing.JComboBox<>();
        JLembalagemAlimento = new javax.swing.JLabel();
        JTFembalagemBebida = new javax.swing.JTextField();
        JLmedidaAlimento = new javax.swing.JLabel();
        JCBmedidaAlimento = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro de produtos");

        JLnome.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLnome.setText("Nome");
        JLnome.setName("Jl1"); // NOI18N

        JTFnome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTFnomeActionPerformed(evt);
            }
        });

        JLquantidade.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLquantidade.setText("Quantidade");
        JLquantidade.setName("Jl1"); // NOI18N

        JLpreco.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLpreco.setText("Preço");
        JLpreco.setName("Jl1"); // NOI18N

        JBsalvar.setBackground(new java.awt.Color(102, 102, 102));
        JBsalvar.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        JBsalvar.setForeground(new java.awt.Color(255, 255, 255));
        JBsalvar.setText("Salvar");
        JBsalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBsalvarActionPerformed(evt);
            }
        });

        JBcancelar.setBackground(new java.awt.Color(255, 0, 0));
        JBcancelar.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        JBcancelar.setForeground(new java.awt.Color(255, 255, 255));
        JBcancelar.setText("Cancelar");
        JBcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBcancelarActionPerformed(evt);
            }
        });

        JTFpreco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTFprecoActionPerformed(evt);
            }
        });

        JLtipoProduto.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLtipoProduto.setText("Tipo de produto");
        JLtipoProduto.setName("Jl1"); // NOI18N

        JCBtipoProduto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "Alimento", "Bebida" }));
        JCBtipoProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JCBtipoProdutoActionPerformed(evt);
            }
        });

        JLproduto.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLproduto.setText("Produto");

        JLtipoAlimento.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLtipoAlimento.setText("Tipo");
        JLtipoAlimento.setName("Jl1"); // NOI18N

        JCBtipoAlimento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "Prato", "Lanche", "Diversos" }));
        JCBtipoAlimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JCBtipoAlimentoActionPerformed(evt);
            }
        });

        JLalimento.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLalimento.setText("Alimento");

        JLbebida.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLbebida.setText("Bebida");

        JLembalagemBebida.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLembalagemBebida.setText("Peso");
        JLembalagemBebida.setName("Jl1"); // NOI18N

        JTFembalagemAlimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTFembalagemAlimentoActionPerformed(evt);
            }
        });

        JLtipoBebida.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLtipoBebida.setText("Tipo");
        JLtipoBebida.setName("Jl1"); // NOI18N

        JCBtipoBebida.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "Água", "Suco", "Refrigerante", "Outro" }));
        JCBtipoBebida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JCBtipoBebidaActionPerformed(evt);
            }
        });

        JSquantidade.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));

        JLmedidaBebida.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLmedidaBebida.setText("Medida");

        JCBmedidaBebida.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "ml", "l" }));
        JCBmedidaBebida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JCBmedidaBebidaActionPerformed(evt);
            }
        });

        JLembalagemAlimento.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLembalagemAlimento.setText("Peso");
        JLembalagemAlimento.setName("Jl1"); // NOI18N

        JTFembalagemBebida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JTFembalagemBebidaActionPerformed(evt);
            }
        });

        JLmedidaAlimento.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLmedidaAlimento.setText("Medida");

        JCBmedidaAlimento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "g", "kg" }));
        JCBmedidaAlimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JCBmedidaAlimentoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(canvas1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(201, 201, 201))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(JBcancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(JBsalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(JLalimento)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(JLbebida)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(JLembalagemAlimento)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(JTFembalagemAlimento, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(JLmedidaAlimento)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(JCBmedidaAlimento, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(JLtipoAlimento)
                                        .addGap(17, 17, 17)
                                        .addComponent(JCBtipoAlimento, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(JLembalagemBebida)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(JTFembalagemBebida, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(JLmedidaBebida)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(JCBmedidaBebida, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(1, 1, 1))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(JLtipoBebida, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(JCBtipoBebida, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(JLproduto)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(JLquantidade)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(JSquantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(JLpreco)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(JTFpreco, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(JLtipoProduto)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(JCBtipoProduto, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(JLnome)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(JTFnome, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(canvas1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLproduto))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JLnome)
                    .addComponent(JTFnome, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JSquantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(JLquantidade))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JLpreco)
                        .addComponent(JTFpreco, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JCBtipoProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLtipoProduto))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLalimento))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JLtipoAlimento)
                    .addComponent(JCBtipoAlimento, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JLmedidaAlimento)
                        .addComponent(JCBmedidaAlimento, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(JLembalagemAlimento)
                        .addComponent(JTFembalagemAlimento, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLbebida))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JLtipoBebida)
                    .addComponent(JCBtipoBebida, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JLembalagemBebida)
                    .addComponent(JLmedidaBebida)
                    .addComponent(JCBmedidaBebida, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JTFembalagemBebida, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JBcancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBsalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void JTFnomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTFnomeActionPerformed

    }//GEN-LAST:event_JTFnomeActionPerformed

    private void JBsalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBsalvarActionPerformed
        int value = (Integer) JSquantidade.getValue();

        if (!JTFnome.getText().equals("")) {
            if (value != 0) {
                if (!JTFpreco.getText().equals("")) {
                    if (JCBtipoProduto.getSelectedIndex() !=  0) {

                        String nome = JTFnome.getText();
                        int quantidade = value;
                        Double preco = Double.parseDouble(JTFpreco.getText());

                        if (JCBtipoProduto.getSelectedIndex() == 1) { //alimento

                            if (JCBtipoAlimento.getSelectedIndex() != 0) {

                                int tipoAlimento = JCBtipoAlimento.getSelectedIndex();
                                int embalagem = 0;
                                int medidaAlimento = JCBmedidaAlimento.getSelectedIndex();

                                if (!JTFembalagemAlimento.getText().equals("")) {

                                    embalagem = Integer.parseInt(JTFembalagemAlimento.getText());

                                    if (JCBmedidaAlimento.getSelectedIndex() != 0) {

                                        if (JCBmedidaAlimento.getSelectedIndex() == 1) {
                                            medidaAlimento = 1;
                                        } else if (JCBmedidaAlimento.getSelectedIndex() == 2) {
                                            medidaAlimento = 2;
                                        }

                                        alimento objAlimento = new alimento(tipoAlimento, medidaAlimento, nome, quantidade, preco, embalagem);
                                        this.listaProdutos.add(objAlimento);

                                        JOptionPane.showMessageDialog(rootPane, "Alimento cadastrado com sucesso.");
                                        clear();

                                    } else {
                                        JOptionPane.showMessageDialog(rootPane, "Informe a unidade de medida.");
                                    }

                                } else {
                                    JOptionPane.showMessageDialog(rootPane, "Informe o valor da embalagem.");
                                }

                            } else {
                                JOptionPane.showMessageDialog(rootPane, "Informe o tipo de alimento.");
                            }

                        } else if (JCBtipoProduto.getSelectedIndex() == 2) { //bebida

                            if (JCBtipoBebida.getSelectedIndex() != 0) {

                                int tipoBebida = JCBtipoBebida.getSelectedIndex();
                                int embalagem = 0;
                                int medidaBebida = JCBmedidaBebida.getSelectedIndex();

                                if (!JTFembalagemBebida.getText().equals("")) {

                                    embalagem = Integer.parseInt(JTFembalagemBebida.getText());

                                    if (JCBmedidaBebida.getSelectedIndex() != 0) {

                                        if (JCBmedidaBebida.getSelectedIndex() == 1) {
                                            medidaBebida = 1;
                                        } else if (JCBmedidaBebida.getSelectedIndex() == 2) {
                                            medidaBebida = 2;
                                        }

                                        bebida objBebida = new bebida(tipoBebida, medidaBebida, nome, quantidade, preco, embalagem);
                                        this.listaProdutos.add(objBebida);

                                        JOptionPane.showMessageDialog(rootPane, "Bebida cadastrada com sucesso.");
                                        clear();

                                    } else {
                                        JOptionPane.showMessageDialog(rootPane, "Informe a unidade de medida.");
                                    }

                                } else {
                                    JOptionPane.showMessageDialog(rootPane, "Informe o valor da embalagem.");
                                }

                            } else {
                                JOptionPane.showMessageDialog(rootPane, "Informe o tipo de bebida.");
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Informe o tipo de produto.");
                    }
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Informe o preço do produto.");
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Informe a quantidade do produto.");
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Informe o nome do produto.");
        }

    }//GEN-LAST:event_JBsalvarActionPerformed


    private void JBcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBcancelarActionPerformed
        clear();
    }//GEN-LAST:event_JBcancelarActionPerformed

    private void JCBtipoProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JCBtipoProdutoActionPerformed
        if (JCBtipoProduto.getSelectedIndex() == 0) {
            JCBtipoAlimento.setEnabled(false);
            JCBtipoBebida.setEnabled(false);
            JTFembalagemAlimento.setText("");
            JTFembalagemAlimento.setEnabled(false);
            JTFembalagemBebida.setText("");
            JTFembalagemBebida.setEnabled(false);
            JCBmedidaAlimento.setEnabled(false);
            JCBmedidaBebida.setEnabled(false);
        } else if (JCBtipoProduto.getSelectedIndex() == 1) {
            JCBtipoAlimento.setEnabled(true);
            JCBtipoBebida.setEnabled(false);
            JTFembalagemAlimento.setEnabled(true);
            JTFembalagemBebida.setEnabled(false);
            JCBmedidaAlimento.setEnabled(true);
            JCBmedidaBebida.setEnabled(false);
        } else if (JCBtipoProduto.getSelectedIndex() == 2) {
            JCBtipoAlimento.setEnabled(false);
            JCBtipoBebida.setEnabled(true);
            JTFembalagemAlimento.setEnabled(false);
            JTFembalagemBebida.setEnabled(true);
            JCBmedidaAlimento.setEnabled(false);
            JCBmedidaBebida.setEnabled(true);
        }
    }//GEN-LAST:event_JCBtipoProdutoActionPerformed

    private void JCBtipoAlimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JCBtipoAlimentoActionPerformed
      
    }//GEN-LAST:event_JCBtipoAlimentoActionPerformed

    private void JTFembalagemAlimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTFembalagemAlimentoActionPerformed

    }//GEN-LAST:event_JTFembalagemAlimentoActionPerformed

    private void JCBtipoBebidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JCBtipoBebidaActionPerformed
    }//GEN-LAST:event_JCBtipoBebidaActionPerformed

    private void JCBmedidaBebidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JCBmedidaBebidaActionPerformed
    }//GEN-LAST:event_JCBmedidaBebidaActionPerformed

    private void JTFembalagemBebidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTFembalagemBebidaActionPerformed

    }//GEN-LAST:event_JTFembalagemBebidaActionPerformed

    private void JCBmedidaAlimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JCBmedidaAlimentoActionPerformed
    }//GEN-LAST:event_JCBmedidaAlimentoActionPerformed

    private void JTFprecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JTFprecoActionPerformed
      
    }//GEN-LAST:event_JTFprecoActionPerformed

    public void clear() {
        JTFnome.setText("");
        JSquantidade.setValue(1);
        JTFpreco.setText("");
        JCBtipoProduto.setSelectedIndex(0);
        JCBtipoAlimento.setSelectedIndex(0);
        JCBtipoBebida.setSelectedIndex(0);
        JTFembalagemAlimento.setText("");
        JTFembalagemBebida.setText("");
        JCBmedidaAlimento.setSelectedIndex(0);
        JCBmedidaBebida.setSelectedIndex(0);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBcancelar;
    private javax.swing.JButton JBsalvar;
    private javax.swing.JComboBox<String> JCBmedidaAlimento;
    private javax.swing.JComboBox<String> JCBmedidaBebida;
    private javax.swing.JComboBox<String> JCBtipoAlimento;
    private javax.swing.JComboBox<String> JCBtipoBebida;
    private javax.swing.JComboBox<String> JCBtipoProduto;
    private javax.swing.JLabel JLalimento;
    private javax.swing.JLabel JLbebida;
    private javax.swing.JLabel JLembalagemAlimento;
    private javax.swing.JLabel JLembalagemBebida;
    private javax.swing.JLabel JLmedidaAlimento;
    private javax.swing.JLabel JLmedidaBebida;
    private javax.swing.JLabel JLnome;
    private javax.swing.JLabel JLpreco;
    private javax.swing.JLabel JLproduto;
    private javax.swing.JLabel JLquantidade;
    private javax.swing.JLabel JLtipoAlimento;
    private javax.swing.JLabel JLtipoBebida;
    private javax.swing.JLabel JLtipoProduto;
    private javax.swing.JSpinner JSquantidade;
    private javax.swing.JTextField JTFembalagemAlimento;
    private javax.swing.JTextField JTFembalagemBebida;
    private javax.swing.JTextField JTFnome;
    private javax.swing.JTextField JTFpreco;
    private java.awt.Canvas canvas1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    // End of variables declaration//GEN-END:variables
}
