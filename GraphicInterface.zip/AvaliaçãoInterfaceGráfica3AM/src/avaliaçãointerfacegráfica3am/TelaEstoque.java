package avaliaçãointerfacegráfica3am;

import java.util.LinkedList;
import javax.swing.JOptionPane;

public class TelaEstoque extends javax.swing.JFrame {

    LinkedList<produto> listaProdutos;
 
    public TelaEstoque(LinkedList<produto> listaProdutos) {
        initComponents();
        this.listaProdutos = listaProdutos;
        
        JCBprodutos.addItem(" -");
        for (int i = 0; i < this.listaProdutos.size(); i++){
            produto objProduto = this.listaProdutos.get(i);
            JCBprodutos.addItem(objProduto.getNome());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        JLoperacao = new javax.swing.JLabel();
        JRBentrada = new javax.swing.JRadioButton();
        JRBretirada = new javax.swing.JRadioButton();
        JLproduto = new javax.swing.JLabel();
        JCBprodutos = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        JBcancelar = new javax.swing.JButton();
        JBsalvar = new javax.swing.JButton();
        JSquantidade = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Controle de estoque");

        JLoperacao.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLoperacao.setText("Operação");

        buttonGroup1.add(JRBentrada);
        JRBentrada.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JRBentrada.setText("Entrada");
        JRBentrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JRBentradaActionPerformed(evt);
            }
        });

        buttonGroup1.add(JRBretirada);
        JRBretirada.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JRBretirada.setText("Retirada");

        JLproduto.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        JLproduto.setText("Produto");

        jLabel1.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel1.setText("Quantidade");

        JBcancelar.setBackground(new java.awt.Color(255, 0, 0));
        JBcancelar.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        JBcancelar.setForeground(new java.awt.Color(255, 255, 255));
        JBcancelar.setText("Cancelar");
        JBcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBcancelarActionPerformed(evt);
            }
        });

        JBsalvar.setBackground(new java.awt.Color(102, 102, 102));
        JBsalvar.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        JBsalvar.setForeground(new java.awt.Color(255, 255, 255));
        JBsalvar.setText("Salvar");
        JBsalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBsalvarActionPerformed(evt);
            }
        });

        JSquantidade.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(JSquantidade))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(JLoperacao)
                        .addGap(18, 18, 18)
                        .addComponent(JRBentrada)
                        .addGap(18, 18, 18)
                        .addComponent(JRBretirada))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(JLproduto)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(JCBprodutos, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(JBcancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(JBsalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JLoperacao)
                    .addComponent(JRBentrada)
                    .addComponent(JRBretirada))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JLproduto)
                    .addComponent(JCBprodutos, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(JSquantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(JBcancelar)
                    .addComponent(JBsalvar))
                .addContainerGap(60, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void JBsalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBsalvarActionPerformed
        int value = (Integer)JSquantidade.getValue();
          
        if (JRBretirada.isSelected() || JRBentrada.isSelected()) {
            if (JCBprodutos.getSelectedIndex() != 0) {
                if (value > 0) {
                    
                    int quantidade = value;
                    int posicao = JCBprodutos.getSelectedIndex() - 1;
                    produto objProduto = this.listaProdutos.get(posicao);
                    
                    if (JRBretirada.isSelected()) {
                        boolean resultado = objProduto.retirada(quantidade);
                        
                        if(resultado == true){
                            JOptionPane.showMessageDialog(rootPane, "Produto retirado com sucesso.");
                            clear();
                        } else {
                            JOptionPane.showMessageDialog(rootPane, "Erro ao retirar produto.");
                        }
                        
                    } else if (JRBentrada.isSelected()) {
                        
                     boolean resultado = objProduto.entrada(quantidade);
                        
                        if(resultado == true){
                            JOptionPane.showMessageDialog(rootPane, "Produto adicionado com sucesso.");
                            clear();
                        } else {
                            JOptionPane.showMessageDialog(rootPane, "Erro ao adicionar produto.");
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Informe uma quantidade positiva.");
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Selecione o produto.");
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Informe a operação desejada.");
        }
    }//GEN-LAST:event_JBsalvarActionPerformed

    private void JBcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBcancelarActionPerformed
        clear();
    }//GEN-LAST:event_JBcancelarActionPerformed

    private void JRBentradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JRBentradaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JRBentradaActionPerformed

       
     public void clear() {
        buttonGroup1.clearSelection();
        JCBprodutos.setSelectedIndex(0);
        JSquantidade.setValue(1);
    }
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBcancelar;
    private javax.swing.JButton JBsalvar;
    private javax.swing.JComboBox<String> JCBprodutos;
    private javax.swing.JLabel JLoperacao;
    private javax.swing.JLabel JLproduto;
    private javax.swing.JRadioButton JRBentrada;
    private javax.swing.JRadioButton JRBretirada;
    private javax.swing.JSpinner JSquantidade;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
